<?php

// phpcs:disable Yoast.NamingConventions.NamespaceName.MaxExceeded

// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.
namespace Yoast\WP\SEO\AI\HTTP_Request\Domain\Exceptions;

/**
 * Class to manage a 503 - service unavailable response.
 */
class Service_Unavailable_Exception extends Remote_Request_Exception {

}
